Hello,

This is an installation of the office suite 'Microsoft Office', this is a legally activated copy (SO WITHOUT PIRACY OR CRACKS).

The idea is that you click the file: "Click on me to install" and then the setup will start.

~Mealman1551~